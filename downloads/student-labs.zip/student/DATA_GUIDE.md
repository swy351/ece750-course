# Student data guide

Source URLs, revisions and original acquisition hashes are in SOURCES.json and COURSE_SOURCES_2025.json. Current packaged-file hashes are in MANIFEST.sha256. Those original-source manifests are provenance, not a list of answer files to download.

| Activity | Input and unit | Available outcomes / evaluation boundary |
|---|---|---|
| Week 1 | 12 SATD-corpus comments, id/projectname/commenttext | No supplied labels. These rows were removed from Week 5's distributed sample to avoid revealing the annotation exercise through development labels. |
| Week 2 | Four synthetic scenarios in the notebook | Manual coding exercise, no model/reference annotations. They are not OSDI cases. |
| Weeks 3–4 | 24 synthetic Java cases: id, code, policy, split; 12 authentic unlabeled Apache file excerpts | No reference judgments or rationales. Preserve development/test split. Policy is contextual input, not a gold judgment. Real-code catch counts were removed. JDT implementation is completed in the course environment; the notebook is the experiment record. |
| Week 5 | 1,988 comments after reserving Week 1 rows | Development labels (`satd`, `classification`) cover training and validation only. Test-project labels withheld. Source sample originally has 100 positives/300 negatives per project, so this is not natural prevalence. Fit vocabulary on training only; select thresholds on validation. |
| Week 6 | 745 Ant class records | `bug` is an observed count; derive bug presence for explanatory GLM. Do not include outcomes among predictors. This dataset is not a private predictive holdout. |
| Week 9 | 2,000 BGL and 2,000 HDFS messages: id, LineId, system, Content | Gold templates/EventIds and raw logs with embedded outcome markers excluded. Fixed llm_ids identify the comparison batch, not answers. |
| Week 10 | Three OpenRCA Bank windows, metrics, logs, sampled traces | Incident timestamps/instructions are given; root-cause labels, upstream predictions and diagnosis traces withheld. Epoch seconds for metrics/logs, milliseconds for traces. Display UTC+8. Trace durations retain source units; only approximately 10% of traces were sampled. The preceding window is not certified healthy. This is a small teaching sample from the pinned mirror documented in SOURCES.json. |
| Week 11 | 240 JIT records: project, timestamps, change metrics, message, bounded diff context, split | `development_labels.csv` contains buggy labels for training/validation only. Supplied test IDs lack labels. Original selection is balanced and thus not natural prevalence. Author timestamps are not integration or label-availability dates. Functional defect labels do not reproduce PerfJIT's performance task. |
| Week 12 / Week 5 Qt extension | Qt components in train.csv and test_features.csv | `post_bugs` only in training. `comp` is the ID. The provided stratified two-thirds/one-third split uses seed 750 and matches the instructor walkthrough. Q1–Q3 use training data. Q4 tunes inside training only. |
| Assignment 3 companion | Mylyn classes in train.csv and test_features.csv | `post-release-bugs` only in training; `classname` is the ID. Same partition policy as Qt. The companion does not replace an individually assigned dataset. |

A name suggesting historical measurement does not prove a feature was available at prediction time. Audit measurement timing and avoid outcome proxies. Test feature files contain the source predictor columns, not an approved feature list. Restrict your model to justified predictors and record exclusions.

For all blind tasks, submit a CSV with stable IDs, method name, predicted outcome/template/component, score where applicable, and uncertainty. The instructor retains evaluation labels and supplies scores or releases labels after predictions are frozen. Agreement between methods is not accuracy. Public source datasets may expose answers elsewhere; obey the course evaluation protocol.

Weeks 7–8 use your own detector evidence, proposal and peer feedback, not new labeled datasets. No worked notebooks, solutions, authored model responses, private grading keys, original R analysis scripts or instructor HTML previews are included.
