# Starter validation

These are intentionally unfinished student exercises. All code cells are syntax checked and setup/data-loading cells are executed with TODOs left blank. Analysis correctness and live LLM inference cannot be validated until students implement them. Distributed notebooks and previews contain no saved outputs or execution counts. See VALIDATION.json for the starter smoke-test record.
