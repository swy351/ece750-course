# ECE 750 — Student notebooks

Start by extracting the complete ZIP. Open `student/START_HERE.html` to choose a week or browse an answer-free HTML preview. The 13 notebooks comprise twelve weekly activities and an Assignment 3 Mylyn companion. Weeks 7–8 are consolidation/proposal worksheets; Week 7 is optional.

## Setup
Run these commands from the extracted package directory (the directory containing `student/`):

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -r student/requirements.txt
python -m ipykernel install --user --name ece750-student --display-name "ECE750 student"
```

Open notebooks in your notebook editor and select the ECE750 student kernel. Run with the working directory `student/` or `student/notebooks/`. The ZIP supplies all local inputs; individual Drive notebooks alone are insufficient. Keep the folder structure intact.

## Completing a lab
1. Read the goal, paper connections, data guide and submission requirements.
2. Run setup and data loading; implement and document the data checks.
3. Complete the traditional method before inspecting model suggestions.
4. Complete the LLM/agent protocol, validate its responses and record all tool calls.
5. Compare matched inputs, explain disagreements and uncertainty, and export stable-ID predictions.
6. Replace written TODOs with evidence-based responses, restart the kernel and rerun. Keep outputs in your submitted copy.

Starter cells are intentionally incomplete and saved without outputs. A successful starter run checks loading/setup only; it is not a completed analysis. Import the analysis libraries you need in your implementation cells.

## LLM access
No model download or API call occurs by default. With a locally installed Ollama model, set `ECE750_MODEL` to its name in the notebook process environment and enable `RUN_LIVE=True` only after writing and checking your prompt. Optional `ECE750_OLLAMA_URL` and `ECE750_CONTEXT` configure the service and context size. `student_tools.llm_json` is transport/logging support, not a supplied analysis or agent. It records requests and responses under `student/runs/`.

Without model access, submit an explicit **not run** protocol: prompt, input selection, response schema, proposed tools, budget and evaluation plan. Never invent responses. Your instructor decides whether execution is required for grading.

## Data boundaries
Training and validation labels are available for supervised fitting and tuning. Test answers, code-case judgments, log gold templates and root-cause answers are excluded. Do not fetch reference answers from source repositories or instructor material. Freeze test predictions before requesting instructor feedback. Ant's observed bug outcomes are supplied because Week 6 is explanatory analysis, not blind prediction. See DATA_GUIDE.md for exact boundaries and caveats.

## Submission
Submit your completed notebook, requested prediction/evidence CSVs in `submissions/`, run logs (or not-run status), and your discussion responses. Use stable IDs and state how thresholds, features and prompts were chosen. Follow the course's assignment deadlines and grading policy; this package does not introduce new deadlines or weights.
