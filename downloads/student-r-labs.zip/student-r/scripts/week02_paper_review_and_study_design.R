ROOT <- if (file.exists("student_tools.R")) normalizePath(".") else normalizePath("..")
stopifnot(file.exists(file.path(ROOT, "student_tools.R")))
source(file.path(ROOT, "student_tools.R"), local = TRUE)
SEED <- 750L
set.seed(SEED)
RUN_LIVE <- FALSE
options(width = 90)
if (requireNamespace("knitr", quietly = TRUE)) {
  knitr::opts_chunk$set(fig.width = 8, fig.height = 4, collapse = TRUE)
}

scenarios <- data.frame(
id = c("F1", "F2", "F3", "F4"),
text = c("Required audit write fails. The handler suppresses the exception and returns success.", "Optional cache read fails. The handler retries the authoritative value and returns it.", "A cleanup block returns a value while a parent operation has a pending failure.", "An error is logged and translated to another exception. The caller contract is unavailable."), stringsAsFactors = FALSE)

# TODO: implement data checks and a bounded schema/sample summary.

# TODO: implement your traditional method. Add focused cells as needed.

# TODO: create the requested table/plot or workshop evidence record.

# TODO: define allowed inputs, prompt, response schema and any bounded read-only tools.
prompt <- NULL
model_response <- NULL
# Opt in only after completing and checking the prompt and data boundary.
if (RUN_LIVE) {
  stopifnot(is.character(prompt), length(prompt) == 1L, nzchar(prompt))
  model_response <- llm_json(prompt, run_live = TRUE, run_name = "week02_paper_review_and_study_design")
}
# TODO: validate ID coverage, types, evidence, allowed fields and tool/row budgets.
# Never evaluate model-produced code or formula strings with eval(parse(...)).

# TODO: compare matched inputs and document failures, uncertainty, cost and latency.

SUBMISSIONS <- file.path(ROOT, "submissions")
dir.create(SUBMISSIONS, showWarnings = FALSE)
# TODO: export completed predictions with stable IDs using write.csv(..., row.names = FALSE).
# Never export placeholder predictions.

sessionInfo()
