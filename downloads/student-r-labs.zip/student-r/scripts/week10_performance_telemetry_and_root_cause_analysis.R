ROOT <- if (file.exists("student_tools.R")) normalizePath(".") else normalizePath("..")
stopifnot(file.exists(file.path(ROOT, "student_tools.R")))
source(file.path(ROOT, "student_tools.R"), local = TRUE)
SEED <- 750L
set.seed(SEED)
RUN_LIVE <- FALSE
options(width = 90)
if (requireNamespace("knitr", quietly = TRUE)) {
  knitr::opts_chunk$set(fig.width = 8, fig.height = 4, collapse = TRUE)
}

incidents <- read_csv("data/week10/incidents.csv")
metrics <- read_csv("data/week10/metric_container.csv.gz")
app_metrics <- read_csv("data/week10/metric_app.csv.gz")
logs <- read_csv("data/week10/log_service.csv.gz")
traces <- read_csv("data/week10/trace_span.csv.gz")

# TODO: implement data checks and a bounded schema/sample summary.

# TODO: implement your traditional method. Add focused cells as needed.

# TODO: create the requested table/plot or workshop evidence record.

# TODO: define allowed inputs, prompt, response schema and any bounded read-only tools.
prompt <- NULL
model_response <- NULL
# Opt in only after completing and checking the prompt and data boundary.
if (RUN_LIVE) {
  stopifnot(is.character(prompt), length(prompt) == 1L, nzchar(prompt))
  model_response <- llm_json(prompt, run_live = TRUE, run_name = "week10_performance_telemetry_and_root_cause_analysis")
}
# TODO: validate ID coverage, types, evidence, allowed fields and tool/row budgets.
# Never evaluate model-produced code or formula strings with eval(parse(...)).

# TODO: compare matched inputs and document failures, uncertainty, cost and latency.

SUBMISSIONS <- file.path(ROOT, "submissions")
dir.create(SUBMISSIONS, showWarnings = FALSE)
# TODO: export completed predictions with stable IDs using write.csv(..., row.names = FALSE).
# Never export placeholder predictions.

sessionInfo()
