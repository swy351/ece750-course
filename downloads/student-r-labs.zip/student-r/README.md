# ECE 750 — R student labs

13 R Markdown notebooks match the Python student edition: Weeks 1–12 and the Assignment 3 Mylyn companion. Open notebooks/ in RStudio. Analysis cells are TODOs; no worked answers, model responses or withheld evaluation labels are supplied. Training labels remain available where needed.

## Setup

Use R and RStudio. In the R console, install packages once:

```r
install.packages(c("rmarkdown", "knitr", "jsonlite", "httr", "digest"))
# Optional implementations for the Week 5 text classifier:
install.packages(c("text2vec", "glmnet"))
```

Extract the whole ZIP. Open a .Rmd file, run its setup and data chunks, complete the tasks and click Knit. Keep data/ and student_tools.R in place. RStudio includes Pandoc; outside RStudio install Pandoc or set RSTUDIO_PANDOC to its containing directory. A plain script companion is also supplied in scripts/: run it from this package root, e.g. `Rscript scripts/week06_software_metrics_and_explanatory_modeling.R`. The scripts have the same TODOs; read the Rmd for instructions.

From the package root, render a notebook after completing it:

```r
rmarkdown::render("notebooks/week06_software_metrics_and_explanatory_modeling.Rmd")
```

## Traditional analysis and LLM/agent comparison

The readings, discussion questions, tasks, IDs, supplied splits, submission schemas and rubrics match the Python edition. Select justified methods rather than copying library defaults. Preserve source column names (`check.names = FALSE`); use bracket access for hyphenated names. R and Python random seeds do not yield identical samples; export fold IDs when comparing languages. Neither language needs to beat the other numerically.

Weeks 3–4 require Java AST/JDT work in the course environment; R analyzes detector exports and records the experiment. A regex over Java text is not an equivalent AST detector. Weeks 7–8 are worksheets, not new required data analyses.

For the optional real model call, configure an installed Ollama model locally, e.g. `Sys.setenv(ECE750_MODEL = "your-installed-model-name")`, complete the prompt, then set `RUN_LIVE <- TRUE`. The helper does not install models or run generated code. It records requests, raw responses, parsing/network errors, latency and reported token counts under runs/. Students implement response-schema validation and bounded, allowlisted agent tools. Record the actual model/version and settings; a fixed seed does not guarantee model determinism. Inspect records before sharing; include only permitted course inputs. Leave RUN_LIVE false if unavailable and submit the protocol marked not run.

## Withheld evaluation and deliverables

Read DATA_GUIDE.md for each dataset's boundary and source manifests/licenses for provenance. Test outcomes, gold log templates and root causes remain withheld. Do not fetch answers from public source repositories. Tune only on development/training data, freeze predictions and let the instructor score them. Use the assignment handout's exact columns and stable IDs, with `write.csv(..., row.names = FALSE)`. A scaffold that runs without errors is not a completed lab. Supply the completed .Rmd, rendered HTML, run records (or not-run declaration), predictions and interpretation. Include sessionInfo().
